# The Resistance

This repo contains code for a command-line application to manage events (called "affairs" in the code), created as part of an assignment for CSCI 4602 at Austin Peay State University.

The below questions should be answered _in detail_ regarding your submission!

##### Reflect on how you determined the architecture of your application. What process did you use to determine which classes to define? #####
> The Principle of Least Knowledge / Law of Demeter - classes should only interact with their intimate
> friends (not friends of friends).
> Looked at the UML Diagram to help determine where to start and add on later when I needed values.
 

##### Did you receive help from any other sources (classmates, etc)? If so, please list who (be specific!). #####
> Jordan Weaver helped me understand the npx tsc --watch and that I needed to run it on a seperate
> tab. 
> https://www.tutorialsteacher.com/typescript/for-loop - had to remember different for loops for
> javascript
> https://www.scaler.com/topics/typescript/for-loop-in-typescript/ - more loop info...



##### Approximately how many hours did it take you to complete this assignment? #####
> 8-10 hrs


##### On a scale of 1 (too easy) to 10 (too challenging), how difficult was this assignment? #####
> 7/10, it was challenging, but not too bad once you sit down and work on it.


##### Did you encounter any problems in this assignment we should warn students about in the future? How can we make the assignment better? #####
> You need to run npx tsc --watch in the background after running npm install and npx tsc index.ts

