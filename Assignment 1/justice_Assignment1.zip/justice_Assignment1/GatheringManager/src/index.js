"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UI = require("./ui"); //import UI
UI.start(); //start up the UI
