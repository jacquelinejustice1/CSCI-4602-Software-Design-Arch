export interface IShopTotalView{
    getView(): string;
  }
