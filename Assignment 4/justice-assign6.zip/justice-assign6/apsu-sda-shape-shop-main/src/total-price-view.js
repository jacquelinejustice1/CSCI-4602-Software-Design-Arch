"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TotalPriceView = void 0;
var TotalPriceView = /** @class */ (function () {
    function TotalPriceView(model) {
        this.model = model;
    }
    TotalPriceView.prototype.getView = function () {
        if (this.model.allProducts().length === 0) {
            return "the cart is empty";
        }
        var products = this.model.allProducts();
        var total = 0;
        for (var i = 0; i < products.length; i++) {
            total += products[i].getPrice();
        }
        return "Total Price: $".concat(total.toFixed(2));
    };
    return TotalPriceView;
}());
exports.TotalPriceView = TotalPriceView;
