export interface IShopViewRemove{
    getView(): string;
}