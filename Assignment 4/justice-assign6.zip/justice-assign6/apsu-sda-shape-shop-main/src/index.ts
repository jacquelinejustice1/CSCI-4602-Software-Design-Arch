import * as UI from './ui'; //import UI

UI.start(); //start up the UI