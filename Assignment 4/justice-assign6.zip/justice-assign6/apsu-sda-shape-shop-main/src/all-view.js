"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AllProductsView = void 0;
var AllProductsView = /** @class */ (function () {
    function AllProductsView(model) {
        this.model = model;
    }
    AllProductsView.prototype.getView = function () {
        if (this.model.allProducts().length === 0) {
            return "the cart is empty";
        }
        return this.model.shape_shop_state();
    };
    return AllProductsView;
}());
exports.AllProductsView = AllProductsView;
