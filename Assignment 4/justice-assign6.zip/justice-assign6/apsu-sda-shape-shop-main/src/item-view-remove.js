"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RemoveItemListView = void 0;
var RemoveItemListView = /** @class */ (function () {
    function RemoveItemListView(model) {
        this.model = model;
    }
    RemoveItemListView.prototype.getView = function () {
        var products = this.model.allProducts();
        if (this.model.allProducts().length === 0) {
            return "the cart is empty";
        }
        var result = "";
        for (var i = 0; i < products.length; i++) {
            result += "\n".concat(i, ":  ").concat(products[i].getName());
        }
        return "Name(s): ".concat(result);
    };
    return RemoveItemListView;
}());
exports.RemoveItemListView = RemoveItemListView;
