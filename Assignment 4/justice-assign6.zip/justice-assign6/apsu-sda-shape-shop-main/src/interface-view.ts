
export interface IShopView{
    getView(): string;
  }
