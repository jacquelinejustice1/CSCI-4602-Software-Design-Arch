"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.start = start;
//User Interface for The Shopping Cart 
//@author James Church
var model_1 = require("./model");
var controller1_1 = require("./controller1");
var total_price_view_1 = require("./total-price-view");
var item_view_remove_1 = require("./item-view-remove");
var all_view_1 = require("./all-view");
function start() {
    var model = new model_1.ShapeShopModel();
    var totalView = new total_price_view_1.TotalPriceView(model);
    var removeView = new item_view_remove_1.RemoveItemListView(model);
    var allView = new all_view_1.AllProductsView(model);
    var controller = new controller1_1.ShapeShopController(model, allView, removeView, totalView);
    controller.start();
}
