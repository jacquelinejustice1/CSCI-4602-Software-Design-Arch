"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShapeShopController = void 0;
var readlineSync = require("readline-sync"); //for easier repeated prompts
var products_1 = require("./products");
var ShapeShopController = /** @class */ (function () {
    function ShapeShopController(model, view, viewRemove, viewTotal) {
        this.model = model;
        this.view = view;
        this.viewRemove = viewRemove;
        this.viewTotal = viewTotal;
    }
    ;
    ShapeShopController.prototype.start = function () {
        while (true) { //run until we exit
            console.log("Welcome to the Shape Store! We offer the best shapes! Pick an option:\n       1. Add an item to the cart.\n       2. Remove an item to the cart.\n       3. View the items in the cart.\n       4. View the price of all items.\n       5. Quit.");
            var response = readlineSync.question('> ');
            if (response === '5' || response.slice(0, 2).toLowerCase() === ':q') {
                break; //stop looping, thus leaving method
            }
            switch (response) { //handle each response
                case '1':
                    var product = this.letUserSelectItem();
                    var quantity = this.letUserSelectQuantity();
                    this.model.addItemToCart(product, quantity);
                    console.log(this.model.allProducts());
                    break;
                case '2':
                    console.log(this.viewRemove.getView());
                    var itemToRemove = this.removeItemFromCart();
                    this.model.removeItemFromCart(itemToRemove);
                    console.log(this.model.allProducts());
                    break;
                case '3':
                    console.log(this.view.getView());
                    break;
                case '4':
                    console.log(this.viewTotal.getView());
                    break;
                default: console.log('Invalid option!');
            }
            console.log(''); //extra empty line for revisiting
        }
    };
    ShapeShopController.prototype.letUserSelectItem = function () {
        while (true) {
            console.log("Here you can select your shape. \n Pick an option: \n        \n 1. Buy a Triangle! \n        \n 2. Buy a Square! \n        \n 3. Buy a Pentagon! \n        \n 4. Go back. Don't buy anything.");
            var response = readlineSync.question('> ');
            switch (response) {
                case '1': return new products_1.Product("Triangle", 3.5, "It's got three sides!");
                case '2': return new products_1.Product("Square", 4.5, "It's got four sides!");
                case '3': return new products_1.Product("Pentagon", 5.5, "It's got five sides!");
                default: console.log('Invalid option! Please choose a valid shape.');
            }
        }
    };
    ShapeShopController.prototype.letUserSelectQuantity = function () {
        console.log("How many of this shape would you like to purchase?");
        var response = readlineSync.question('> ');
        return parseInt(response);
    };
    ShapeShopController.prototype.removeItemFromCart = function () {
        console.log("Select an item to be removed from the cart.");
        var response = readlineSync.question('> ');
        var toRemove = parseInt(response);
        return toRemove;
    };
    return ShapeShopController;
}());
exports.ShapeShopController = ShapeShopController;
