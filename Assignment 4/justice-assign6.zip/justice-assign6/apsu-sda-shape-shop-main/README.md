# Refactoring the Purchasing System.

This assignment is 100% original by James Church. All faults are his.

##### Did you receive help from any other sources (classmates, etc)? If so, please list who (be specific!). #####
> Yes, Jordan Weaver advised me to put things in seperate classes when I asked if she did that (it made things soooo much easier!). Looked up in the other assignment how to find something based on index in for loop style.


##### Approximately how many hours did it take you to complete this assignment? #####
> 5-7 hrs.


##### On a scale of 1 (too easy) to 10 (too challenging), how difficult was this assignment? #####
> 7-8


##### Did you encounter any problems in this assignment we should warn students about in the future? How can we make the assignment better? #####
> I think that there we're not any crazy problems in the assignment, but it is challenging with the multiple views. With examples from class, it is easier to figure out. I used consol.log in my controller class, and if that was not allowed then I would make that a little clearer. 